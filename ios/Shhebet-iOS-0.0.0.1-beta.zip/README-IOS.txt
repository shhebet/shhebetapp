Shhebet iOS 0.0.0.1 beta

Open Shhebet.xcodeproj in Xcode, select your Apple Team, then archive the
Release scheme to produce an IPA. This ZIP contains the Web bundle under
Shhebet/Web and does not require a Shhebet server.
